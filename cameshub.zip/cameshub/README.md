# CamesHub

Penghubung semua website Cames (CamesAcademic, CamesAi, dst.).
Tanpa dependensi — hanya butuh **Node.js 18+**. Tidak perlu `npm install`.

## Menjalankan

```bash
node server.js        # atau: npm start
```

Buka `http://localhost:3000`. Port bisa diubah lewat `.env` (`PORT=3000`).

## Mengelola konten

Semua konten ada di folder `data/` — cukup edit filenya, **tidak perlu restart**.

### Website (`data/sites.json`)

```json
[
  {
    "name": "CamesAcademic",
    "description": "Platform belajar berbasis AI.",
    "url": "https://academic.cames.my.id",
    "icon": "/assets/academic.png",
    "accent": "#2563eb"
  }
]
```

- `icon`: path gambar (taruh di `public/assets/`), boleh dikosongkan (diganti huruf awal).
- `accent`: warna kartu (format `#RRGGBB`).

### Update / kotak gambar (`data/updates.json`)

```json
[
  {
    "id": "1",
    "title": "Fitur baru di CamesAcademic",
    "text": "Ceritakan update-nya secara singkat (maks. 400 karakter).",
    "image": "/uploads/banner-oktober.jpg",
    "link": "https://academic.cames.my.id",
    "linkLabel": "Coba sekarang",
    "createdAt": "2026-10-12T08:00:00Z",
    "published": true
  }
]
```

- Urutan di file = urutan tampil (paling atas muncul pertama).
- `image`: taruh gambar di `data/uploads/`, lalu tulis `/uploads/namafile.jpg`
  (nama file hanya huruf, angka, `-`, `_`; format PNG/JPG/WEBP/GIF; rasio 16:9 paling pas).
  Boleh juga alamat `https://…`. Kosongkan bila tanpa gambar.
- `link` dan `linkLabel` opsional. `published: false` = disembunyikan.

## Deploy singkat (VPS)

```bash
npm i -g pm2
cd cameshub && pm2 start server.js --name cameshub && pm2 save
```

Contoh Nginx untuk `cames.my.id` (lalu pasang HTTPS dengan certbot):

```nginx
server {
  server_name cames.my.id;
  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-Proto $scheme;
  }
}
```

## Struktur

```
server.js            server statis + API baca-saja
public/              situs (index.html, style.css, app.js, assets/)
data/sites.json      daftar website
data/updates.json    daftar update
data/uploads/        gambar update
```
