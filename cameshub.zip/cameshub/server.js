"use strict";
/**
 * CamesHub — server tanpa dependensi (hanya modul bawaan Node 18+).
 *  - Situs publik   : /
 */
const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");

/* ------------------------------ .env sederhana ------------------------------ */
(function loadEnv() {
  const file = path.join(__dirname, ".env");
  if (!fs.existsSync(file)) return;
  for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/i);
    if (!m || line.trim().startsWith("#")) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (process.env[m[1]] === undefined) process.env[m[1]] = v;
  }
})();

const PORT = Number(process.env.PORT) || 3000;
const HOST = process.env.HOST || "0.0.0.0";
const PUBLIC_DIR = path.join(__dirname, "public");
const DATA_DIR = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : path.join(__dirname, "data");
const UPLOAD_DIR = path.join(DATA_DIR, "uploads");
const UPDATES_FILE = path.join(DATA_DIR, "updates.json");
const SITES_FILE = path.join(DATA_DIR, "sites.json");

fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(UPDATES_FILE)) fs.writeFileSync(UPDATES_FILE, "[]\n");

/* ------------------------------ Penyimpanan JSON ------------------------------ */
function readJson(file, fallback) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return fallback;
  }
}
const getUpdates = () => readJson(UPDATES_FILE, []);
const getSites = () => readJson(SITES_FILE, []);

/* ------------------------------ Util ------------------------------ */
const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".ico": "image/x-icon",
  ".txt": "text/plain; charset=utf-8",
};

function baseHeaders(extra = {}) {
  return {
    "Content-Security-Policy":
      "default-src 'self'; img-src 'self' data:; style-src 'self' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; script-src 'self'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
    ...extra,
  };
}

function send(res, status, body, headers = {}) {
  res.writeHead(status, baseHeaders(headers));
  res.end(body);
}
function sendJson(res, status, obj, headers = {}) {
  send(res, status, JSON.stringify(obj), { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store", ...headers });
}
function notFound(res) {
  send(res, 404, "<!doctype html><meta charset=utf-8><title>404</title><body style=\"font-family:system-ui;padding:3rem\"><h1>404</h1><p>Halaman tidak ditemukan.</p><a href=\"/\">Kembali ke CamesHub</a>", {
    "Content-Type": "text/html; charset=utf-8",
  });
}

function sendFile(res, file, headers = {}) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return notFound(res);
    const ext = path.extname(file).toLowerCase();
    res.writeHead(200, baseHeaders({ "Content-Type": MIME[ext] || "application/octet-stream", "Content-Length": st.size, ...headers }));
    fs.createReadStream(file).pipe(res);
  });
}


/* ------------------------------ Server utama ------------------------------ */
const server = http.createServer(async (req, res) => {
  try {
    let pathname;
    try {
      pathname = decodeURIComponent(new URL(req.url, "http://x").pathname);
    } catch {
      return notFound(res);
    }


    if (req.method !== "GET" && req.method !== "HEAD") return notFound(res);

    if (pathname === "/api/updates") {
      const list = (Array.isArray(getUpdates()) ? getUpdates() : [])
        .filter((u) => u && u.published !== false && u.title)
        .map((u, i) => ({
          id: String(u.id || i),
          title: String(u.title).slice(0, 80),
          text: String(u.text || "").slice(0, 400),
          image: /^\/uploads\/[\w-]{1,80}\.(png|jpe?g|webp|gif)$/i.test(u.image || "") || /^https:\/\//.test(u.image || "") ? u.image : "",
          link: /^https?:\/\//.test(u.link || "") ? u.link : "",
          linkLabel: String(u.linkLabel || "").slice(0, 30),
          createdAt: u.createdAt || "",
        }));
      return sendJson(res, 200, list, { "Cache-Control": "no-cache" });
    }
    if (pathname === "/api/sites") return sendJson(res, 200, getSites(), { "Cache-Control": "no-cache" });

    if (pathname.startsWith("/uploads/")) {
      const name = pathname.slice(9);
      if (!/^[\w-]{1,80}\.(png|jpe?g|webp|gif)$/i.test(name)) return notFound(res);
      return sendFile(res, path.join(UPLOAD_DIR, name), { "Cache-Control": "public, max-age=2592000, immutable" });
    }

    // Aset statis publik
    let rel = pathname === "/" ? "/index.html" : pathname;
    const full = path.normalize(path.join(PUBLIC_DIR, rel));
    
    if (!full.startsWith(PUBLIC_DIR + path.sep)) return notFound(res);
    
    const cache = rel.endsWith(".html") ? "no-cache" : "public, max-age=3600";
    return sendFile(res, full, { "Cache-Control": cache });
  } catch (err) {
    console.error(err);
    if (!res.headersSent) sendJson(res, 500, { error: "Terjadi kesalahan server" });
    else res.end();
  }
});

server.listen(PORT, HOST, () => {
  console.log(`CamesHub berjalan di http://localhost:${PORT}`);
});
