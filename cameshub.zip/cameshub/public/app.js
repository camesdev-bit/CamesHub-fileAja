(function () {
  "use strict";
  document.documentElement.classList.add("js");

  var $ = function (s, r) { return (r || document).querySelector(s); };
  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  var SVG = "http://www.w3.org/2000/svg";
  function icon(pathD, size) {
    var s = document.createElementNS(SVG, "svg");
    s.setAttribute("viewBox", "0 0 24 24");
    s.setAttribute("width", size || 20);
    s.setAttribute("height", size || 20);
    s.setAttribute("fill", "none");
    s.setAttribute("stroke", "currentColor");
    s.setAttribute("stroke-width", "2.2");
    s.setAttribute("stroke-linecap", "round");
    s.setAttribute("stroke-linejoin", "round");
    s.setAttribute("aria-hidden", "true");
    var p = document.createElementNS(SVG, "path");
    p.setAttribute("d", pathD);
    s.appendChild(p);
    return s;
  }
  var P = {
    ext: "M7 17 17 7M8 7h9v9",
    left: "m15 18-6-6 6-6",
    right: "m9 18 6-6-6-6",
    pause: "M8 5v14M16 5v14",
    play: "M7 4.5v15l13-7.5z",
    mega: "M3 11v2a1 1 0 0 0 1 1h3l6 4V6L7 10H4a1 1 0 0 0-1 1ZM17 9a4 4 0 0 1 0 6"
  };
  var reduceMotion = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* ============================ BAR ATAS ============================ */
  var topbar = $("#topbar");
  function onScroll() {
    topbar.classList.toggle("over-hero", window.scrollY < 24);
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();

  /* ============================ SIDEBAR ============================ */
  var menuBtn = $("#menuBtn");
  var closeBtn = $("#closeBtn");
  var sidebar = $("#sidebar");
  var overlay = $("#overlay");

  function openMenu() {
    sidebar.removeAttribute("inert");
    sidebar.setAttribute("aria-hidden", "false");
    overlay.hidden = false;
    requestAnimationFrame(function () {
      sidebar.classList.add("open");
      overlay.classList.add("show");
    });
    document.documentElement.classList.add("menu-open");
    menuBtn.setAttribute("aria-expanded", "true");
    setTimeout(function () { closeBtn.focus(); }, 60);
  }
  function closeMenu(returnFocus) {
    sidebar.classList.remove("open");
    overlay.classList.remove("show");
    document.documentElement.classList.remove("menu-open");
    menuBtn.setAttribute("aria-expanded", "false");
    sidebar.setAttribute("aria-hidden", "true");
    sidebar.setAttribute("inert", "");
    setTimeout(function () { overlay.hidden = true; }, 260);
    if (returnFocus) menuBtn.focus();
  }
  menuBtn.addEventListener("click", openMenu);
  closeBtn.addEventListener("click", function () { closeMenu(true); });
  overlay.addEventListener("click", function () { closeMenu(true); });
  document.addEventListener("keydown", function (e) {
    if (!sidebar.classList.contains("open")) return;
    if (e.key === "Escape") { closeMenu(true); return; }
    if (e.key === "Tab") {
      // jebakan fokus di dalam sidebar
      var f = sidebar.querySelectorAll("a[href], button");
      if (!f.length) return;
      var first = f[0];
      var last = f[f.length - 1];
      if (e.shiftKey && document.activeElement === first) { last.focus(); e.preventDefault(); }
      else if (!e.shiftKey && document.activeElement === last) { first.focus(); e.preventDefault(); }
    }
  });
  sidebar.addEventListener("click", function (e) {
    var a = e.target.closest("a");
    if (a && (a.hasAttribute("data-close") || a.getAttribute("target") === "_blank")) closeMenu(false);
  });

  /* scrollspy: tandai menu aktif sesuai bagian yang terlihat */
  var spyLinks = {};
  Array.prototype.forEach.call(sidebar.querySelectorAll("[data-spy]"), function (a) { spyLinks[a.getAttribute("data-spy")] = a; });
  function setActive(id) {
    Object.keys(spyLinks).forEach(function (k) {
      if (k === id) spyLinks[k].setAttribute("aria-current", "true");
      else spyLinks[k].removeAttribute("aria-current");
    });
  }
  setActive("top");
  if ("IntersectionObserver" in window) {
    var spy = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) { if (en.isIntersecting) setActive(en.target.id); });
    }, { rootMargin: "-45% 0px -50% 0px" });
    ["top", "update", "website"].forEach(function (id) { var s = document.getElementById(id); if (s) spy.observe(s); });
  }

  /* muncul halus saat di-scroll */
  var revealIO = null;
  if ("IntersectionObserver" in window && !reduceMotion) {
    revealIO = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add("in"); revealIO.unobserve(en.target); }
      });
    }, { rootMargin: "0px 0px -8% 0px", threshold: 0.05 });
  }
  function watchReveal(node) {
    if (!node) return;
    if (revealIO) revealIO.observe(node);
    else node.classList.add("in");
  }
  Array.prototype.forEach.call(document.querySelectorAll(".reveal"), watchReveal);

  /* ============================ UTIL DATA ============================ */
  function getJson(url) {
    return fetch(url, { headers: { Accept: "application/json" } }).then(function (r) {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.json();
    });
  }
  function domainOf(url) {
    try { return new URL(url).host; } catch (e) { return url; }
  }
  function safeHttp(url) {
    try {
      var u = new URL(url);
      return u.protocol === "http:" || u.protocol === "https:" ? u.href : "";
    } catch (e) { return ""; }
  }
  function safeImg(src) {
    if (!src) return "";
    if (/^\/(uploads|assets)\/[\w.\-]+$/.test(src)) return src;
    if (/^data:image\/(png|jpeg|webp|gif);base64,/.test(src)) return src;
    return safeHttp(src) && /^https:/.test(src) ? src : "";
  }
  function safeColor(c) { return /^#[0-9a-f]{6}$/i.test(c || "") ? c : "#2563eb"; }
  function fmtDate(iso) {
    if (!iso) return "";
    try { return new Date(iso).toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" }); }
    catch (e) { return ""; }
  }
  function initial(name) {
    return (name || "?").replace(/^Cames/i, "").charAt(0).toUpperCase() || "C";
  }
  function iconTile(cls, s) {
    var t = el("span", cls);
    var src = safeImg(s.icon);
    if (src) {
      var im = el("img");
      im.src = src;
      im.alt = "";
      im.loading = "lazy";
      t.appendChild(im);
    } else {
      t.textContent = initial(s.name);
    }
    return t;
  }

  /* ============================ WEBSITE ============================ */
  function renderSites(sites) {
    var grid = $("#siteGrid");
    var side = $("#sideSites");
    var quick = $("#heroLinks");
    var foot = $("#footSites");
    grid.textContent = "";
    side.textContent = "";
    quick.textContent = "";
    Array.prototype.slice.call(foot.querySelectorAll("a")).forEach(function (a) { a.remove(); });

    sites.forEach(function (s) {
      var href = safeHttp(s.url);
      if (!href) return;
      var accent = safeColor(s.accent);

      var card = el("article", "site-card");
      card.style.setProperty("--accent", accent);
      var cover = el("div", "site-cover");
      cover.appendChild(el("span", "site-domain", domainOf(href)));
      cover.appendChild(iconTile("site-icon", s));
      card.appendChild(cover);
      var body = el("div", "site-body");
      body.appendChild(el("h3", null, s.name));
      body.appendChild(el("p", null, s.description || ""));
      var btn = el("a", "btn");
      btn.href = href;
      btn.target = "_blank";
      btn.rel = "noopener noreferrer";
      btn.appendChild(document.createTextNode("Buka " + s.name + " "));
      btn.appendChild(icon(P.ext, 18));
      body.appendChild(btn);
      card.appendChild(body);
      grid.appendChild(card);

      var a = el("a", "side-site");
      a.href = href;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      var left = el("span", "ss-left");
      left.appendChild(iconTile("ss-icon", s));
      var tx = el("span", "ss-text");
      tx.appendChild(document.createTextNode(s.name));
      tx.appendChild(el("small", null, domainOf(href)));
      left.appendChild(tx);
      a.appendChild(left);
      a.appendChild(icon(P.ext, 18));
      side.appendChild(a);

      var q = el("a");
      q.href = href;
      q.target = "_blank";
      q.rel = "noopener noreferrer";
      q.appendChild(iconTile("q-ic", s));
      q.appendChild(document.createTextNode(s.name));
      quick.appendChild(q);

      var f = el("a", null, s.name);
      f.href = href;
      f.target = "_blank";
      f.rel = "noopener noreferrer";
      foot.appendChild(f);
    });
    if (!grid.children.length) {
      var empty = el("div", "empty-box");
      empty.appendChild(el("h3", null, "Belum ada website"));
      empty.appendChild(el("p", null, "Daftar website akan muncul di sini."));
      grid.appendChild(empty);
    }
  }

  /* ============================ UPDATE (story banner) ============================ */
  function renderUpdates(list) {
    var box = $("#updateBox");
    box.textContent = "";

    if (!list.length) {
      var empty = el("div", "empty-box");
      var ic = el("span", "ic");
      ic.appendChild(icon(P.mega, 28));
      empty.appendChild(ic);
      empty.appendChild(el("h3", null, "Belum ada update"));
      empty.appendChild(el("p", null, "Kabar terbaru dari Cames akan tampil di sini. Pantau terus ya!"));
      box.appendChild(empty);
      return;
    }

    var wrap = el("div", "u-wrap");
    var viewport = el("div", "u-viewport");
    viewport.setAttribute("role", "group");
    viewport.setAttribute("aria-roledescription", "carousel");
    viewport.setAttribute("aria-label", "Update terbaru");
    viewport.tabIndex = 0;
    var track = el("div", "u-track");

    var slides = list.map(function (u, i) {
      var s = el("article", "u-slide");
      s.setAttribute("role", "group");
      s.setAttribute("aria-roledescription", "slide");
      s.setAttribute("aria-label", i + 1 + " dari " + list.length);

      var media = el("div", "u-media");
      var src = safeImg(u.image);
      if (src) {
        var im = el("img");
        im.src = src;
        im.alt = "";
        im.loading = i === 0 ? "eager" : "lazy";
        im.decoding = "async";
        media.appendChild(im);
      } else {
        media.className = "u-media fallback";
        var lg = el("img");
        lg.src = "/assets/logo.png";
        lg.alt = "";
        media.appendChild(lg);
      }
      s.appendChild(media);
      s.appendChild(el("div", "u-shade"));

      var body = el("div", "u-body");
      var d = fmtDate(u.createdAt);
      if (d) body.appendChild(el("time", "u-date", d));
      body.appendChild(el("h3", null, u.title));
      if (u.text) body.appendChild(el("p", null, u.text));
      var href = safeHttp(u.link);
      if (href) {
        var a = el("a", "btn btn-white");
        a.href = href;
        a.target = "_blank";
        a.rel = "noopener noreferrer";
        a.appendChild(document.createTextNode((u.linkLabel || "Selengkapnya") + " "));
        a.appendChild(icon(P.ext, 18));
        body.appendChild(a);
      }
      s.appendChild(body);
      track.appendChild(s);
      return s;
    });
    viewport.appendChild(track);
    wrap.appendChild(viewport);

    var index = 0;
    var userPaused = reduceMotion;
    var hover = false;
    var bars = [];
    var playBtn = null;
    var countEl = null;

    if (list.length > 1) {
      var barsWrap = el("div", "u-bars");
      list.forEach(function (_, i) {
        var b = el("button", "u-bar");
        b.type = "button";
        b.setAttribute("aria-label", "Ke update " + (i + 1));
        var track2 = el("span");
        track2.appendChild(el("i"));
        b.appendChild(track2);
        b.addEventListener("click", function () { go(i); });
        // saat animasi satu bar selesai -> lanjut ke berikutnya
        b.addEventListener("animationend", function () { if (i === index) go(index + 1); });
        barsWrap.appendChild(b);
        bars.push(b);
      });
      wrap.appendChild(barsWrap);

      var tools = el("div", "u-tools");
      countEl = el("span", "u-count");
      tools.appendChild(countEl);
      playBtn = el("button", "icon-btn");
      playBtn.type = "button";
      var prev = el("button", "icon-btn u-nav");
      prev.type = "button";
      prev.setAttribute("aria-label", "Update sebelumnya");
      prev.appendChild(icon(P.left));
      var next = el("button", "icon-btn u-nav");
      next.type = "button";
      next.setAttribute("aria-label", "Update berikutnya");
      next.appendChild(icon(P.right));
      tools.appendChild(playBtn);
      tools.appendChild(prev);
      tools.appendChild(next);
      wrap.appendChild(tools);

      prev.addEventListener("click", function () { go(index - 1); });
      next.addEventListener("click", function () { go(index + 1); });
      playBtn.addEventListener("click", function () {
        userPaused = !userPaused;
        syncPlay();
        restartBar();
      });
    }
    box.appendChild(wrap);

    function syncPlay() {
      if (!playBtn) return;
      playBtn.textContent = "";
      playBtn.appendChild(icon(userPaused ? P.play : P.pause));
      playBtn.setAttribute("aria-label", userPaused ? "Putar otomatis" : "Jeda putar otomatis");
      wrap.classList.toggle("paused", userPaused || hover);
    }
    function restartBar() {
      bars.forEach(function (b, k) {
        b.classList.remove("run");
        b.classList.toggle("done", k < index);
        b.classList.toggle("active", k === index);
      });
      if (!bars.length || userPaused) { wrap.classList.toggle("paused", true); return; }
      // paksa animasi mulai dari awal
      void wrap.offsetWidth;
      bars[index].classList.add("run");
      wrap.classList.toggle("paused", hover);
    }

    function go(i) {
      index = (i + list.length) % list.length;
      track.style.transform = "translateX(" + -index * 100 + "%)";
      slides.forEach(function (s, k) {
        if (k === index) { s.removeAttribute("inert"); s.removeAttribute("aria-hidden"); }
        else { s.setAttribute("inert", ""); s.setAttribute("aria-hidden", "true"); }
      });
      if (countEl) countEl.textContent = index + 1 + " / " + list.length;
      restartBar();
    }

    wrap.addEventListener("mouseenter", function () { hover = true; wrap.classList.toggle("paused", true); });
    wrap.addEventListener("mouseleave", function () { hover = false; wrap.classList.toggle("paused", userPaused); });
    wrap.addEventListener("focusin", function () { hover = true; wrap.classList.toggle("paused", true); });
    wrap.addEventListener("focusout", function () { hover = false; wrap.classList.toggle("paused", userPaused); });

    viewport.addEventListener("keydown", function (e) {
      if (e.key === "ArrowLeft") { go(index - 1); e.preventDefault(); }
      if (e.key === "ArrowRight") { go(index + 1); e.preventDefault(); }
    });

    var startX = null;
    var startY = 0;
    viewport.addEventListener("pointerdown", function (e) {
      if (e.pointerType === "mouse" && e.button !== 0) return;
      startX = e.clientX;
      startY = e.clientY;
    });
    viewport.addEventListener("pointerup", function (e) {
      if (startX == null) return;
      var dx = e.clientX - startX;
      var dy = e.clientY - startY;
      startX = null;
      if (Math.abs(dx) > 45 && Math.abs(dx) > Math.abs(dy) * 1.4) go(index + (dx < 0 ? 1 : -1));
    });
    viewport.addEventListener("pointercancel", function () { startX = null; });

    syncPlay();
    go(0);
  }

  /* ============================ MUAT ============================ */
  function retryBox(target, msg, again) {
    target.textContent = "";
    var b = el("div", "empty-box");
    b.appendChild(el("h3", null, "Gagal memuat"));
    b.appendChild(el("p", null, msg));
    var btn = el("button", "btn btn-outline", "Coba lagi");
    btn.type = "button";
    btn.addEventListener("click", again);
    b.appendChild(btn);
    target.appendChild(b);
  }
  function loadUpdates() {
    getJson("/api/updates").then(renderUpdates).catch(function () {
      retryBox($("#updateBox"), "Update belum bisa dimuat. Periksa koneksimu.", loadUpdates);
    });
  }
  function loadSites() {
    getJson("/api/sites").then(renderSites).catch(function () {
      retryBox($("#siteGrid"), "Daftar website belum bisa dimuat.", loadSites);
    });
  }
  loadUpdates();
  loadSites();
})();
